import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { AuthGuardService } from "../../service/auth-guard.service";
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
    public loggedIn: boolean = false;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public authGuardService: AuthGuardService,
  ) { }

  ngOnInit() {
    this.loggedIn = this.authGuardService.loggedIn;
    console.log(this.loggedIn);
    

    $(window).scroll(function() {    
      var scroll = $(window).scrollTop();
  
      if (scroll >= 400) {
          $("#navbar").addClass("blue");
          $("#navButton").removeClass("btn-primary");
          $("#navButton").addClass("btn-light");
      } else {
          $("#navbar").removeClass("blue");
          $("#navButton").addClass("btn-primary");
          $("#navButton").removeClass("btn-light");
      }
  });

  $('a[href^="#"]').on('click', function(event) {

    var target = $(this.getAttribute('href'));

    if( target.length ) {
        event.preventDefault();
        $('html, body').stop().animate({
            scrollTop: target.offset().top
        }, 1000);
    }
    
    });
  }

  top(){
    this.router.navigate(['/']);

    $('a[href^="#"]').on('click', function(event) {

        var target = $(this.getAttribute('href'));
    
        if( target.length ) {
            event.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top
            }, 1000);
        }
        
        });
  }

}
