import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FlashMessagesModule, FlashMessagesService } from 'angular2-flash-messages/module';
import { Product } from '../../modules/product';
import { Http } from '@angular/http';
import { ProductService } from '../../service/product.service';
import { Order } from "../../modules/order";
import { NgForm } from '@angular/forms';
import { OrderService } from "../../service/order.service";
import { AuthGuardService } from "../../service/auth-guard.service";
import * as moment from 'moment';

@Component({
  selector: 'app-new-order',
  templateUrl: './new-order.component.html',
  styleUrls: ['./new-order.component.css']
})
export class NewOrderComponent implements OnInit {
  id: string;
  product: Product;
  public loggedIn: boolean;

  order: Order = {
    orderName: ' ',
    orderTime: new Date(),
    orderAmount: 0,
    orderPrice: 0,
    isComplete: 0    
  }

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public productService: ProductService,
    public flashMessagesServices: FlashMessagesService,
    public orderService: OrderService,
    public authGuardService: AuthGuardService,
  ) { }

  ngOnInit() {
    this.loggedIn = this.authGuardService.loggedIn;
    //Get Id
    this.id = this.route.snapshot.params['id'];
    //Get Product details
    this.productService.getProduct(this.id).subscribe(product => {
      this.product = product;
      this.order.orderName = product.productName;
      this.order.orderPrice = product.productPrice;
    });
  }
  
  onSubmit(f: NgForm){
    this.order.orderAmount = f.controls['OrderAmount'].value;
    this.order.orderTime = moment().toDate(); //fix me
    // console.log(this.product);

    if(this.order.orderAmount < 0){
      this.flashMessagesServices.show('Please fill in field or positive Amount', {cssClass: 'alert-danger', timeout: 4000});
    } else{
      this.product.availableAmount = (this.product.availableAmount - this.order.orderAmount);
      this.productService.UpdateProduct(this.id, this.product);
      this.orderService.newOrder(this.order);
      this.flashMessagesServices.show('New Order added', {cssClass: 'alert-success', timeout: 4000});
      this.router.navigate(['/']);
    }
    // console.log(this.order);
  }

  onUpdate(ff: NgForm){
    this.order.orderAmount = ff.controls['UpdateAmount'].value;
    // console.log(this.product);

    if(this.order.orderAmount < 0){
      this.flashMessagesServices.show('Please fill in field or positive Amount', {cssClass: 'alert-danger', timeout: 4000});
    } else{
      this.product.availableAmount = (this.order.orderAmount);
      this.productService.UpdateProduct(this.id, this.product);
      this.flashMessagesServices.show('Updated Amount', {cssClass: 'alert-success', timeout: 4000});
      this.router.navigate(['/']);
    }
    // console.log(this.order);
  }

}
