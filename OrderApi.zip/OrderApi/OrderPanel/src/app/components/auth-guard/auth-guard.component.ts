import { Component, OnInit } from '@angular/core';
import { FlashMessagesModule, FlashMessagesService } from 'angular2-flash-messages/module';
import { NgForm } from '@angular/forms';
import { AuthGuardService } from "../../service/auth-guard.service";
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-auth-guard',
  templateUrl: './auth-guard.component.html',
  styleUrls: ['./auth-guard.component.css']
})
export class AuthGuardComponent implements OnInit {
  public userName: string;
  public userPassword: string;
  public loggedIn: number;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public flashMessagesServices: FlashMessagesService,
    public authGuardService: AuthGuardService
  ) { }

  ngOnInit() {
  }

  onSubmit(f: NgForm){
    this.userName = f.controls['userName'].value;
    this.userPassword = f.controls['userPassword'].value;

    // console.log(this.userName+' + '+this.userPassword);

    if(this.userName == null && this.userPassword == null){
      this.flashMessagesServices.show('Please fill in all Fields', {cssClass: 'alert-danger', timeout: 4000});
    } else{
      this.loggedIn = this.authGuardService.getAuthGuard(this.userName,this.userPassword);

      if(this.loggedIn = 1){
        this.flashMessagesServices.show('Signed In', {cssClass: 'alert-success', timeout: 4000});
        this.router.navigate(['/']);
      } else {
        this.flashMessagesServices.show('Incorrect user name or password', {cssClass: 'alert-danger', timeout: 4000});
      }

    }
    
  }

}
