import { Component, OnInit } from '@angular/core';
import { Order } from "../../modules/order";
import { Http } from '@angular/http';
import { OrderService } from "../../service/order.service";
import { AuthGuardService } from "../../service/auth-guard.service";
import { FlashMessagesModule, FlashMessagesService } from 'angular2-flash-messages/module';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-pending-orders',
  templateUrl: './pending-orders.component.html',
  styleUrls: ['./pending-orders.component.css']
})
export class PendingOrdersComponent implements OnInit {
  public orders: Order[];
  public order: Order;
  public loggedIn: boolean;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public orderService: OrderService,
    public authGuardService: AuthGuardService,
    public flashMessagesServices: FlashMessagesService,
  ) { }

  ngOnInit() {
    this.loggedIn = this.authGuardService.loggedIn;

    this.orderService.getOrders()
      .subscribe(value =>{
        this.orders = value;
        // console.log(this.orders);

        // time in seconds
        var i = 0;
        var len = this.orders.length;
        for (i = 0; i < len; i++) {
  
            var startDate = new Date();
            // Do your operations
            var endDate  = new Date(this.orders[i].orderTime);
            console.log(endDate);

            //Easy fix from time difference
            var seconds = ((startDate.getTime() - endDate.getTime()) / 60000)-120;
            this.orders[i].orderSec = seconds;
            // console.log(seconds);
        }

      });
  }

  deleteOrder(id : string) {
    this.orderService.deleteOrder(id);
    this.flashMessagesServices.show('Order Deleted', {cssClass: 'alert-success', timeout: 4000});
    this.router.navigate(['/']);
  }

  updateOrder(id: string) {
    this.orderService.getOrder(id).subscribe(order => {
      this.order = order;
      this.order.isComplete = 1;
      this.order.orderTime = new Date();
      this.orderService.UpdateOrder(id, this.order);
      this.flashMessagesServices.show('Order Updated', {cssClass: 'alert-success', timeout: 4000});
      this.router.navigate(['/']);
    });
  }

}
