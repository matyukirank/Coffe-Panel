import { Injectable } from '@angular/core';
import { Headers, RequestOptions } from '@angular/http';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map'
import { Order } from "../modules/order";
import { Options } from 'selenium-webdriver/edge';

@Injectable()
export class OrderService {
  public order: any;

  constructor(public http: Http) { }

  public url = 'http://localhost:62249/api/Order/';

  getOrders(){
    return this.http.get(this.url).map(res => <Order[]>res.json());
  }

  getOrder(id: string){
    return this.order = this.http.get(this.url+id).map(res => <Order>res.json());
  }
  
  newOrder(order: any){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    this.http.post(this.url, order, options).subscribe(res => console.log(res.text()));
    // console.log("Post");
  }

  deleteOrder(id: string) {
    let orderId = this.url+id;
    this.http.delete(orderId).subscribe(res => console.log(res.text()));
  }

  UpdateOrder(id: string, order: Order){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let orderId = this.url+id;
    this.http.put(orderId, order, options).subscribe(res => console.log(res.text()));
  }

}

