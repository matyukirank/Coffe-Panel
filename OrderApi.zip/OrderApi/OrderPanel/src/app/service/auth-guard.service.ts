import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map'

@Injectable()
export class AuthGuardService {
  public loggedIn: boolean = false;
  public AuthGuard: any;
  public userName: string;

  constructor(public http: Http) { }

  public url = 'http://localhost:62249/api/AuthGuard/';

  getAuthGuard(userName: string, userPassword: string){
    this.userName = userName;
    this.AuthGuard = this.http.get(this.url+userName+'/'+userPassword).map(res => res);
    console.log(this.AuthGuard);
    
    if(this.AuthGuard = 1) {
      this.loggedIn = true;
      console.log('logged');
      return 1;
    } else {
      this.loggedIn = false;
      return 0;
    }
  }

}
