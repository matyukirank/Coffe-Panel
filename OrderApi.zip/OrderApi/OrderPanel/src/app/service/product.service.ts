import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map'
import { Product } from '../modules/product';
import { Headers, RequestOptions } from '@angular/http';

@Injectable()
export class ProductService {
  public product: any;

  constructor(public http: Http) { }

  public url = 'http://localhost:62249/api/Product/';

  getProducts(){
    return this.http.get(this.url)
    .map(res => <Product[]>res.json());
  }

  getProduct(id: string){
    return this.product = this.http.get(this.url+id).map(res => <Product>res.json());
  }

  UpdateProduct(id: string, product: Product){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let productId = this.url+id;
    this.http.put(productId, product, options).subscribe(res => console.log(res.text()));
  }
}
