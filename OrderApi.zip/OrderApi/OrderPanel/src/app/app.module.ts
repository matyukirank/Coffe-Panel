import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { FlashMessagesModule} from 'angular2-flash-messages';
import { FlashMessagesService} from 'angular2-flash-messages';


import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { NewOrderComponent } from './components/new-order/new-order.component';
import { ProductsComponent } from './components/products/products.component';
import { PendingOrdersComponent } from './components/pending-orders/pending-orders.component';
import { AuthGuardComponent } from './components/auth-guard/auth-guard.component';

//Routes
const appRoutes: Routes = [
  {path: '', component: ProductsComponent},
  {path: 'new/:id', component: NewOrderComponent},
  {path: 'kitchen', component: PendingOrdersComponent},
  {path: 'signIn', component: AuthGuardComponent}
];

//Service
import { ProductService } from './service/product.service';
import { OrderService } from './service/order.service';
import { AuthGuardService } from "./service/auth-guard.service";
import { FooterComponent } from './components/footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    NewOrderComponent,
    ProductsComponent,
    PendingOrdersComponent,
    AuthGuardComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    FlashMessagesModule,
  ],
  providers: [
    ProductService,
    OrderService,
    FlashMessagesService,
    AuthGuardService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
