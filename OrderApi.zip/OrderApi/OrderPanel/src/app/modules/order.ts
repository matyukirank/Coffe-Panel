export interface Order {
    orderId?: number;
    orderName?: string;
    orderTime?: Date;
    orderAmount?: number;
    orderPrice?: number;
    isComplete?: number;
    orderSec?: number;
}