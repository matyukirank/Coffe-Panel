export interface Product {
    productId?: number;
    productName?: string;
    productPrice?: number;
    availableAmount?: number;
    url?: string;
}