import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import * as moment from 'moment-timezone';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';

  ngOnInit(){
    $('a[href^="#"]').on('click', function(event) {

      var target = $(this.getAttribute('href'));
  
      if( target.length ) {
          event.preventDefault();
          $('html, body').stop().animate({
              scrollTop: target.offset().top
          }, 1000);
      }
    });
  }
}
