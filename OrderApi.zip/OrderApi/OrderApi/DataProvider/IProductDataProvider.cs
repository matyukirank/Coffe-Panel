﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OrderApi.Models;

namespace OrderApi.DataProvider
{
    public interface IProductDataProvider
    {
        Task<IEnumerable<Products>> GetProducts();

        Task<Products> GetProduct(int ProductId);

        Task AddProduct(Products product);

        Task UpdateProduct(Products product);

        Task DeleteProduct(int ProductId);
    }
}
