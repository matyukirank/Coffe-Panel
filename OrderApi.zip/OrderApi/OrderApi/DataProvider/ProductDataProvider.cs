﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using OrderApi.Models;

namespace OrderApi.DataProvider
{
    public class ProductDataProvider : IProductDataProvider
    {
        private readonly string connectionString = "Server=DESKTOP-CVKC6GP\\SQLEXPRESS;Database=OrderPanel;Trusted_Connection=True;";

        private SqlConnection sqlConnection;

        public async Task AddProduct(Products product)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@ProductName", product.ProductName);
                dynamicParameters.Add("@ProductPrice", product.ProductPrice);
                dynamicParameters.Add("@AvailableAmount", product.AvailableAmount);
                dynamicParameters.Add("@Url", product.Url);

                await sqlConnection.ExecuteAsync(
                    "sp_AddProduct",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task DeleteProduct(int ProductId)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@ProductId", ProductId);
                await sqlConnection.ExecuteAsync(
                    "sp_DeleteProduct",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task<IEnumerable<Products>> GetProducts()
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                return await sqlConnection.QueryAsync<Products>(
                    "sp_GetProducts",
                    null,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task<Products> GetProduct(int ProductId)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@ProductId", ProductId);
                return await sqlConnection.QuerySingleOrDefaultAsync<Products>(
                    "sp_GetProduct",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task UpdateProduct(Products product)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@ProductId", product.ProductId);
                dynamicParameters.Add("@ProductName", product.ProductName);
                dynamicParameters.Add("@ProductPrice", product.ProductPrice);
                dynamicParameters.Add("@AvailableAmount", product.AvailableAmount);
                dynamicParameters.Add("@Url", product.Url);

                await sqlConnection.ExecuteAsync(
                    "sp_UpdateProduct",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }
    }
}
