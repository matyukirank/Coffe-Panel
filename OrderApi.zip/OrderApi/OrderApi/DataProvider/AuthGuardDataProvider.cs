﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using OrderApi.Models;

namespace OrderApi.DataProvider
{
    public class AuthGuardDataProvider : IAuthGuardDataProvider
    {
        private readonly string connectionString = "Server=DESKTOP-CVKC6GP\\SQLEXPRESS;Database=OrderPanel;Trusted_Connection=True;";

        private SqlConnection sqlConnection;

        public async Task<AuthGuard> GetSignIn(string userName)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@UserName", userName);

                return await sqlConnection.QuerySingleOrDefaultAsync<AuthGuard>(
                    "sp_GetSignIn",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }
    }
}
