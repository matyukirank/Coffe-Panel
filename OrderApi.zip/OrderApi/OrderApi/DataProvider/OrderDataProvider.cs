﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using OrderApi.Models;

namespace OrderApi.DataProvider
{
    public class OrderDataProvider : IOrderDataProvider
    {
        private readonly string connectionString = "Server=DESKTOP-CVKC6GP\\SQLEXPRESS;Database=OrderPanel;Trusted_Connection=True;";

        private SqlConnection sqlConnection;

        public async Task AddOrder(Orders order)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@OrderName", order.OrderName);
                dynamicParameters.Add("@OrderTime", order.OrderTime);
                dynamicParameters.Add("@OrderAmount", order.OrderAmount);
                dynamicParameters.Add("@OrderPrice", order.OrderPrice);
                dynamicParameters.Add("@IsComplete", order.IsComplete);

                await sqlConnection.ExecuteAsync(
                    "sp_AddOrder",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task DeleteOrder(int OrderId)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@OrderId", OrderId);

                await sqlConnection.ExecuteAsync(
                    "sp_DeleteOrder",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task<Orders> GetOrder(int OrderId)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@OrderId", OrderId);

                return await sqlConnection.QuerySingleOrDefaultAsync<Orders>(
                    "sp_GetOrder",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task<IEnumerable<Orders>> GetOrders()
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                return await sqlConnection.QueryAsync<Orders>(
                    "sp_GetOrders",
                    null,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task UpdateOrder(Orders order)
        {
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                await sqlConnection.OpenAsync();
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@OrderId", order.OrderId);
                dynamicParameters.Add("@OrderName", order.OrderName);
                dynamicParameters.Add("@OrderTime", order.OrderTime);
                dynamicParameters.Add("@OrderAmount", order.OrderAmount);
                dynamicParameters.Add("@OrderPrice", order.OrderPrice);
                dynamicParameters.Add("@IsComplete", order.IsComplete);

                await sqlConnection.ExecuteAsync(
                    "sp_UpdateOrder",
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure);
            }
        }
    }
}
