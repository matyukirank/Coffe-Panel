﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OrderApi.Models;

namespace OrderApi.DataProvider
{
    public interface IOrderDataProvider
    {
        Task<IEnumerable<Orders>> GetOrders();

        Task<Orders> GetOrder(int OrderId);

        Task AddOrder(Orders order);

        Task UpdateOrder(Orders order);

        Task DeleteOrder(int OrderId);
    }
}
