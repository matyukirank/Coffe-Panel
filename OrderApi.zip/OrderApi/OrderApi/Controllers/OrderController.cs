﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using OrderApi.DataProvider;
using OrderApi.Models;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OrderApi.Controllers
{
    [Route("api/[controller]")]
    public class OrderController : Controller
    {
        private IOrderDataProvider orderDataProvider;

        public OrderController(IOrderDataProvider orderDataProvider)
        {
            this.orderDataProvider = orderDataProvider;
        }

        // GET: api/<controller>
        [HttpGet]
        public async Task<IEnumerable<Orders>> Get()
        {
            return await this.orderDataProvider.GetOrders();
        }

        // GET api/<controller>/5
        [HttpGet("{OrderId}")]
        public async Task<Orders> Get(int OrderId)
        {
            return await this.orderDataProvider.GetOrder(OrderId);
        }

        // POST api/<controller>
        [HttpPost]
        public async Task Post([FromBody]Orders order)
        {
            await this.orderDataProvider.AddOrder(order);
        }

        // PUT api/<controller>/5
        [HttpPut("{OrderId}")]
        public async Task Put(int OrderId, [FromBody]Orders order)
        {
            await this.orderDataProvider.UpdateOrder(order);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{OrderId}")]
        public async Task Delete(int OrderId)
        {
            await this.orderDataProvider.DeleteOrder(OrderId);
        }
    }
}
