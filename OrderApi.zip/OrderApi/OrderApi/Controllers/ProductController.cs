﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using OrderApi.DataProvider;
using OrderApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OrderApi.Controllers
{
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private IProductDataProvider productDataProvider;

        public ProductController(IProductDataProvider productDataProvider)
        {
            this.productDataProvider = productDataProvider;
        }

        // GET: api/<controller>
        [HttpGet]
        public async Task<IEnumerable<Products>> Get()
        {
            return await this.productDataProvider.GetProducts();
        }

        // GET api/<controller>/5
        [HttpGet("{ProductId}")]
        public async Task<Products> Get(int ProductId)
        {
            return await this.productDataProvider.GetProduct(ProductId);
        }

        // POST api/<controller>
        [HttpPost]
        public async Task Post([FromBody]Products product)
        {
            await this.productDataProvider.AddProduct(product);
        }

        // PUT api/<controller>/5
        [HttpPut("{ProductId}")]
        public async Task Put(int ProductId, [FromBody]Products product)
        {
            await this.productDataProvider.UpdateProduct(product);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{ProductId}")]
        public async Task Delete(int ProductId)
        {
            await this.productDataProvider.DeleteProduct(ProductId);
        }
    }
}
