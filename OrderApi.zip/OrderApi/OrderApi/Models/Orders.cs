﻿using System;
using System.Collections.Generic;

namespace OrderApi.Models
{
    public partial class Orders
    {
        public int OrderId { get; set; }
        public string OrderName { get; set; }
        public DateTime? OrderTime { get; set; }
        public int? OrderAmount { get; set; }
        public int? OrderPrice { get; set; }
        public int? IsComplete { get; set; }
    }
}
